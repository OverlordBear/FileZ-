//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.gjx666.common.utils;

import com.seeyon.cap4.form.bean.*;
import com.seeyon.cap4.form.service.CAP4FormManager;
import com.seeyon.ctp.common.AppContext;
import com.seeyon.ctp.workflow.event.WorkflowEventData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WorkflowEventDataKit {
    private static final Logger log = LoggerFactory.getLogger(WorkflowEventDataKit.class);
    private FormDataMasterBean masterBean;
    CAP4FormManager cap4FormManager = AppContext.getBeanByName("cap4FormManager");

    public WorkflowEventDataKit(WorkflowEventData data) {
        if (data != null) {
            Map<String, Object> businessData = data.getBusinessData();
            if (businessData != null) {
                this.masterBean = (FormDataMasterBean)businessData.get("formDataBean");
            }
        }

    }

    public Object getByDisplayName(String displayName) {
        if (this.masterBean != null && displayName != null) {
            try {
                if (cap4FormManager == null) {
                    log.error("无法获取 cap4FormManager Bean，请检查环境");
                    return null;
                } else {
                    Long formId = this.masterBean.getFormTable().getFormId();
                    FormBean formBean = cap4FormManager.getForm(formId, false);
                    if (formBean == null) {
                        log.warn("未找到ID为 {} 的表单定义", formId);
                        return null;
                    } else {
                        FormFieldBean field = formBean.getFieldBeanByDisplay(displayName);
                        if (field != null) {
                            String fieldCode = field.getName();
                            return this.get(fieldCode);
                        } else {
                            log.warn("在表单[{}]中未找到显示名为[{}]的字段", formBean.getFormName(), displayName);
                            return null;
                        }
                    }
                }
            } catch (Exception var7) {
                log.error("WorkflowEventDataKit 通过域名[{}]获取值异常", displayName, var7);
                return null;
            }
        } else {
            return null;
        }
    }

    public String getStringByDisplayName(String displayName) {
        Object val = this.getByDisplayName(displayName);
        return val == null ? "" : String.valueOf(val);
    }

    public Object get(String fieldName) {
        return this.masterBean == null ? null : this.masterBean.getFieldValue(fieldName);
    }

    public String getString(String fieldName) {
        Object val = this.get(fieldName);
        return val == null ? "" : String.valueOf(val);
    }

    public void setByDisplayName(String displayName, Object value) {
        if (this.masterBean != null && displayName != null) {
            try {
                Long formId = this.masterBean.getFormTable().getFormId();
                FormBean formBean = cap4FormManager.getForm(formId, false);
                if (formBean == null) {
                    log.warn("未找到 formId={} 的表单定义", formId);
                    return;
                }

                FormFieldBean field = formBean.getFieldBeanByDisplay(displayName);
                if (field != null) {
                    String fieldCode = field.getName();
                    this.set(fieldCode, value);
                } else {
                    log.warn("在表单[{}]中未找到显示名为[{}]的字段，无法赋值", formBean.getFormName(), displayName);
                }
            } catch (Exception var8) {
                log.error("setByDisplayName 异常: displayName={}, value={}", new Object[]{displayName, value, var8});
            }

        } else {
            log.warn("setByDisplayName 失败：masterBean 为空或 displayName 为空");
        }
    }

    public void set(String fieldName, Object value) {
        if (this.masterBean != null) {
            this.masterBean.addFieldValue(fieldName, value);
        }

    }

    /**
     * 根据【明细表】（如 formson_0001）获取明细行数据
     */
    public List<FormDataSubBean> getDetailRows(String tableName) {
        if (this.masterBean == null) {
            return new ArrayList<>(); // 修正：使用泛型
        }
        List<FormDataSubBean> rows = this.masterBean.getSubData(tableName);
        return rows != null ? rows : new ArrayList<>();
    }

    /**
     * 【新功能】根据【重复表显示名】（中文名）获取明细行数据
     * @param displayName 重复表的显示名，例如 "采购明细"
     * @return 明细行列表
     */
    public List<FormDataSubBean> getDetailRowsByDisplayName(String displayName) {
        if (this.masterBean == null || displayName == null) {
            return new ArrayList<>();
        }

        try {

            // 2. 获取表单定义
            Long formId = this.masterBean.getFormTable().getFormId();
            FormBean formBean = cap4FormManager.getForm(formId, false);

            if (formBean == null) return new ArrayList<>();

            // 3. 遍历所有从表定义，寻找匹配的名字
            List<FormTableBean> subTables = formBean.getSubTableBean();
            for (FormTableBean subTable : subTables) {
                // getDisplay() 就是设计器里看到的“表格名称”
                if (displayName.equals(subTable.getDisplay())) {
                    String tableName = subTable.getTableName(); // 找到 formson_xxxx
                    // log.info("重复表名称映射: [{}] -> [{}]", displayName, tableName);
                    return this.getDetailRows(tableName);
                }
            }

            log.warn("未找到显示名为[{}]的重复表", displayName);
            return new ArrayList<>();

        } catch (Exception e) {
            log.error("通过显示名获取重复表数据异常: {}", displayName, e);
            return new ArrayList<>();
        }
    }

    public boolean isValid() {
        return this.masterBean != null;
    }

    public FormDataMasterBean getMasterBean() {
        return this.masterBean;
    }



    // ==========================================
    // 5. 高级功能区域 (核心扩展)
    // ==========================================

    /**
     * 【加锁】锁定当前数据，防止其他人同时编辑
     * 场景：在进行关键业务操作（如扣减库存、审批通过）前调用
     * @return true: 加锁成功; false: 加锁失败
     */
    public boolean lock() {
        if (this.masterBean == null) return false;
        try {
            return cap4FormManager.lockFormData(this.masterBean.getId());
        } catch (Exception e) {
            log.error("数据加锁失败 masterId={}", this.masterBean.getId(), e);
            return false;
        }
    }

    /**
     * 【解锁】释放数据锁
     * 场景：业务操作完成（无论成功失败）后，必须调用，否则数据会被一直锁死
     */
    public void unlock() {
        if (this.masterBean == null) return;
        try {
            cap4FormManager.unlockFormData(this.masterBean.getId());
        } catch (Exception e) {
            log.error("数据解锁失败 masterId={}", this.masterBean.getId(), e);
        }
    }

    /**
     * 【检查锁】检查当前数据是否正在被其他人编辑
     * @return 返回提示信息字符串（例如："张三正在编辑..."），如果为空字符串则表示未被锁，可以编辑。
     */
    public String checkLock() {
        if (this.masterBean == null) return "数据对象为空";
        try {
            // checkDataLockForEdit 返回空字符串表示无锁，返回具体内容表示被锁的提示信息
            return cap4FormManager.checkDataLockForEdit(String.valueOf(this.masterBean.getId()));
        } catch (Exception e) {
            log.error("检查数据锁异常", e);
            return "检查锁异常";
        }
    }

    /**
     * 【校验】手动触发表单设计器中配置的“校验规则”
     * 场景：代码修改数据后，保存前调用，确保数据符合业务规则
     * @return 错误信息字符串。如果为空字符串，表示校验通过。
     */
    public String validate() {
        if (this.masterBean == null) return "数据对象为空";
        try {
            Long formId = this.masterBean.getFormTable().getFormId();
            FormBean formBean = cap4FormManager.getForm(formId, false);

            // 调用 CAP4 原生校验逻辑
            return cap4FormManager.validate(formBean, this.masterBean);
        } catch (Exception e) {
            log.error("数据校验异常", e);
            return "数据校验发生系统异常: " + e.getMessage();
        }
    }

    /**
     * 【删除】物理删除当前表单数据
     * ⚠️警告：这是硬删除，数据将无法恢复！慎用！
     * @return true: 删除成功
     */
    public boolean delete() {
        if (this.masterBean == null) return false;
        try {
            Long formId = this.masterBean.getFormTable().getFormId();
            return cap4FormManager.deleteFormData(this.masterBean.getId(), formId);
        } catch (Exception e) {
            log.error("删除数据失败 masterId={}", this.masterBean.getId(), e);
            return false;
        }
    }

    /**
     * 【初始化】执行默认值计算与公式
     * 场景：当你 new 了一个空数据后，调用此方法自动填充“当前人”、“当前时间”并执行计算公式
     * @param authId 权限ID (FormAuthViewBean的ID)，决定了计算时应用哪个视图的权限，传 null 则尝试使用默认
     */
    public void fillDefaultValues(Long authId) {
        if (this.masterBean == null) return;
        try {
            Long formId = this.masterBean.getFormTable().getFormId();
            Long masterId = this.masterBean.getId();
            // authId 如果为null，可能需要根据业务逻辑查找一个默认的
            Long finalAuthId = (authId == null) ? 0L : authId;

            // 调用 procDefaultValue
            cap4FormManager.procDefaultValue(formId, masterId, finalAuthId, null, this.masterBean);
        } catch (Exception e) {
            log.error("执行默认值计算失败", e);
        }
    }



    /**
     * 【状态检查】判断表单是否处于启用状态
     */
    public boolean isEnabled() {
        if (this.masterBean == null) return false;
        try {
            Long formId = this.masterBean.getFormTable().getFormId();
            return cap4FormManager.isEnabled(formId);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 【获取定义】暴露底层的 FormBean 对象
     * 场景：如果你需要获取表单的详细配置（如视图列表、绑定关系等），可以使用此方法
     */
    public FormBean getFormBean() {
        if (this.masterBean == null) return null;
        try {
            Long formId = this.masterBean.getFormTable().getFormId();
            return cap4FormManager.getForm(formId, false);
        } catch (Exception e) {
            log.error("获取 FormBean 失败", e);
            return null;
        }
    }
}
