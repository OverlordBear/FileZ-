rem ==========================================
rem  JRebel Config for Seeyon (Clean Local Mode)
rem ==========================================

rem 1. JRebel Agent 核心动态库路径 (不要随意移动该文件)
set JREBEL_PATH=C:\Users\GJX\AppData\Roaming\JetBrains\IntelliJIdea2023.3\plugins\jr-ide-idea\jrebel6\lib\jrebel64.dll

rem 2. 组装启动参数
rem    (这里去掉了显式的 URL 和 Email，它会自动去 C:\Users\GJX\.jrebel 读取授权)
rem
rem    -agentpath: 加载 JRebel 核心引擎
rem    -spring_plugin=true: 开启 Spring 容器热重载 (致远开发必开，否则新 Bean 不生效)
rem    -hibernate_plugin=true: 开启数据库层热重载
rem    -remoting_plugin=false: 强制使用本地文件监控模式 (编译后立即生效，无需同步)
set JREBEL_ARGS=-agentpath:"%JREBEL_PATH%" -Drebel.spring_plugin=true -Drebel.hibernate_plugin=true -Drebel.remoting_plugin=false

rem 3. 将参数注入到 Tomcat 的标准启动变量中
set JAVA_OPTS=%JAVA_OPTS% %JREBEL_ARGS%